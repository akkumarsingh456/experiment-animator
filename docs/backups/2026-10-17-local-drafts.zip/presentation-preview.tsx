import { repairSourceMathSlide } from './src/lib/source-math-repair';
import { SlideCanvas } from './original-preview';
import { paginateLectureSections } from './src/lib/lecture-pages';
import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { GuidedNotesPresentation } from './src/components/GuidedNotesPresentation';
import './src/styles.css';
import type { Slide } from './src/lib/generate.functions';

const slides: Slide[] = [
  {title: 'Current Electricity', kind: 'break', visual: 'cover', caption: '', bullets: ['Explore charge carriers, current and resistance.', 'Connect microscopic motion with measurable circuit quantities.'], notes: [], key_terms: []},
  {title: "Ohm’s Law", kind: 'content', visual: 'graph', bullets: [], notes: [], key_terms: [], sections: [{heading: 'Teacher Notes', kind: 'bullets', lines: [
    '**Learning objective:** Explain the relationship between potential difference and electric current.',
    '**Explanation:** At constant temperature, the current through an ohmic conductor is proportional to the potential difference across it. Resistance is the constant of proportionality.',
    '**Key term — Resistance:** Opposition to the flow of current, measured in ohms.',
    '**Formula:** Ohm’s law | $V=IR$ | $\\Omega$',
    '**Explanation:** Using E = V/l, I = nev d A, and Ohm’s law, one obtains 2 d eE ne vmm ρ = The proportionality between force and drift velocity.',
    '**Explanation:** If the field becomes too strong, there are departures from Ohm’s law in all cases.',
    '**Explanation:** We shall, in the next section, discuss how the motion of electrons reproduces Ohm’s law.',
    '**Derivation of resistance:** $R=\\frac{V}{I}$',
    '**Derivation step 1:** Start from the relation $V=IR$.',
    '**Derivation step 2:** Divide both sides by current $I$: $R=\\frac{V}{I}$.',
    '**Check your understanding:** A potential difference of $12\\,\\mathrm{V}$ produces a current of $2\\,\\mathrm{A}$. Find the resistance.',
    '**Answer:** $R=\\frac{12}{2}=6\\,\\Omega$.',
  ]}]},
  {title: 'Drift velocity and mobility', kind: 'content', visual: 'diagram', bullets: ['Electrons acquire a small average drift velocity in an applied electric field.', 'Mobility relates the magnitude of drift velocity to the electric field.'], notes: ['**Formula:** Mobility | $\\mu=\\frac{v_d}{E}$ | $\\mathrm{m^2\\,V^{-1}\\,s^{-1}}$'], key_terms: []},
];
const original = slides.map(repairSourceMathSlide).flatMap((slide,index)=> slide.kind==='break'?[slide]:paginateLectureSections(slide.sections || [{heading:'Teacher Notes',kind:'bullets',lines:[...slide.bullets,...slide.notes]}],18).map(sections=>({...slide,sections}))).map((slide,index,array)=>({title:slide.title,section:'NCERT notes & illustration',content:<SlideCanvas slide={slide} index={index} total={array.length} editing={false} onChange={()=>{}} subject='Physics' staticView />}));
function Preview() {
  const [originalMode,setOriginalMode]=useState(false);
  const [presenting, setPresenting] = useState(false), [page, setPage] = useState(0);
  return <main style={{padding: '24px', maxWidth: '1520px', margin: 'auto'}}><button id="toggle-style" onClick={()=>{setOriginalMode(!originalMode);setPage(0)}}>Switch presentation style</button><h1 style={{fontSize: 24, fontWeight: 800, marginBottom: 16}}>EduPlan AI · Presentation slides</h1>
    <GuidedNotesPresentation inline presentationSlides={originalMode?original:undefined} mode="notes" slides={slides} title="Current Electricity" klass="12" subject="Physics" pageIndex={page} onPageChange={setPage} onPresent={() => setPresenting(true)} onClose={() => setPresenting(false)} onPdf={() => {}} />
    {presenting && <GuidedNotesPresentation presentationSlides={originalMode?original:undefined} mode="notes" slides={slides} title="Current Electricity" klass="12" subject="Physics" pageIndex={page} onPageChange={setPage} onClose={() => setPresenting(false)} onPdf={() => {}} />}
  </main>;
}
createRoot(document.getElementById('root')!).render(<Preview />);
