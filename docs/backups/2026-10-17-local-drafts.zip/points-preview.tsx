import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import PagedNoteSections from './src/components/PagedNoteSections';
import {paginateLectureSections} from './src/lib/lecture-pages';
import './src/styles.css';
const sections = [
  {heading:'Teacher Notes',kind:'bullets',lines:['**Formula:** Ohm’s law | $V=IR$ | $\\Omega$']},
  {heading:'Reference notes — layout example',kind:'bullets',lines:["The source explains the first important idea in detail so that students can understand its meaning clearly. The next sentence describes a second important idea and its application without changing any source words. Students can refer to Fig. 3.15 and Eq. (3.39) for the original example, using a value of 2.5 in their working. For an ohmic conductor, $V=IR$ connects the current, resistance and potential difference under the stated conditions. The sentences are displayed separately with space between the points, preserving the original wording and mathematical notation."]},
];
function Preview(){const [page,setPage]=useState(0); const pages=paginateLectureSections(sections,18);return <main style={{background:'#172e42',minHeight:'100vh',padding:30}}><div style={{background:'white',borderRadius:18,maxWidth:1100,margin:'auto',padding:36}}><header style={{display:'flex',justifyContent:'space-between',marginBottom:22}}><h1 style={{fontSize:32,fontWeight:700}}>Ohm’s Law</h1><span>Local layout check · page {page+1} / {pages.length}</span></header><div style={{height:570,display:'flex'}}><PagedNoteSections sections={pages[page]} subject="Physics" scale="present" /></div><button onClick={()=>setPage((page+1)%pages.length)}>Next page</button></div></main>};
createRoot(document.getElementById('root')!).render(<Preview/>);
