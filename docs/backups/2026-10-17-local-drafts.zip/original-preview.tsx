import { MathematicsTopicVisual } from "./src/components/MathematicsTopicVisual";
import { isMathematics } from "./src/lib/mathematics-presentation";
import React,{useState,useEffect} from 'react';
import {Button} from './src/components/ui/button';import {Card,CardContent} from './src/components/ui/card';import {Badge} from './src/components/ui/badge';import {Input} from './src/components/ui/input';import {Textarea} from './src/components/ui/textarea';import {Loader2} from 'lucide-react';import {MathText} from './src/components/MathText';import PagedNoteSections from './src/components/PagedNoteSections';import {renderLessonIllustrationDataUrl} from './src/lib/napkin-infographic';import type {Slide} from './src/lib/generate.functions';
const PenNotesBlock=()=>null;const SimPanel=()=>null;const isLanguageSubject=(subject?:string)=>/english|hindi|sanskrit/i.test(subject||'');
function McqSlideBody({ slide, staticView = false }: { slide: Slide; staticView?: boolean }) {
  const [reveal, setReveal] = useState(staticView);
  useEffect(() => { setReveal(staticView); }, [slide, staticView]);
  const mcq = slide.mcq;
  if (!mcq) return null;
  return (
    <div className="p-6 flex flex-col gap-3 min-h-0 overflow-hidden">
      <p className="font-display text-base sm:text-lg font-semibold leading-snug"><MathText text={mcq.question} /></p>
      <ol className="grid sm:grid-cols-2 gap-2">
        {mcq.options.map((o) => {
          const isCorrect = reveal && o.key === mcq.answer;
          return (
            <li key={o.key}
              className={`rounded-md border p-2.5 text-sm flex gap-2 ${isCorrect ? "border-emerald-500 bg-emerald-50 text-emerald-900" : "border-border/60 bg-card"}`}
            >
              <span className="font-mono font-bold">{o.key}.</span>
              <span><MathText text={o.text} /></span>
            </li>
          );
        })}
      </ol>
      <div className="flex flex-wrap items-center gap-2 mt-1">
        {!staticView && <Button size="sm" variant={reveal ? "outline" : "default"} onClick={() => setReveal((v) => !v)}>
          {reveal ? "Hide answer" : "Show answer"}
        </Button>}
        {reveal && (
          <Badge className="rounded-full bg-emerald-500/15 text-emerald-700 border border-emerald-500/30">
            Correct: {mcq.answer}
          </Badge>
        )}
      </div>
      {reveal && mcq.explanation && (
        <p className="text-xs text-muted-foreground italic border-l-2 border-primary/40 pl-2"><MathText text={mcq.explanation} /></p>
      )}
    </div>
  );
}

function ChapterSlideBody({ slide }: { slide: Slide }) {
  return (
    <div className="p-6 flex flex-col gap-2 min-h-0 overflow-hidden">
      <p className="text-[13px] leading-relaxed whitespace-pre-wrap">{slide.chapter_text}</p>
      {slide.figures?.length ? (
        <p className="text-[11px] text-muted-foreground italic">Referenced NCERT figures: {slide.figures.join(", ")}</p>
      ) : null}
    </div>
  );
}

function BreakSlideBody({ slide }: { slide: Slide }) {
  if (slide.visual === "cover") {
    return (
      <div className="h-full min-h-0 px-8 py-6 sm:px-16 flex flex-col justify-center gap-5">
        <div className="text-center">
          <div className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">Chapter overview</div>
          <p className="mt-2 text-sm text-muted-foreground">{slide.caption}</p>
          <h2 className="mt-4 font-display text-3xl sm:text-5xl font-extrabold leading-tight">{slide.title}</h2>
        </div>
        <section className="mx-auto w-full max-w-3xl rounded-xl border border-primary/20 bg-primary/5 p-6 sm:p-8">
          <h3 className="font-display text-xl sm:text-2xl font-bold mb-4">What you will learn</h3>
          <ul className="grid sm:grid-cols-2 gap-x-8 gap-y-3 text-sm sm:text-base leading-relaxed">
            {(slide.bullets || []).map((item, index) => <li key={index} className="flex gap-2"><span className="text-primary font-bold">{index + 1}.</span><span>{item}</span></li>)}
          </ul>
        </section>
      </div>
    );
  }
  return (
    <div className="p-8 grid place-items-center text-center gap-3">
      <div className="text-4xl">☕</div>
      <h3 className="font-display text-2xl font-bold">Break Time</h3>
      <p className="text-sm text-muted-foreground max-w-md">{slide.caption}</p>
      <ul className="text-sm space-y-1">
        {(slide.bullets || []).map((b, i) => <li key={i}>• {b}</li>)}
      </ul>
    </div>
  );
}

function SlideCanvas({
  slide, index, total, editing, onChange, imageUrl, imageLoading, onRegenImage, subject, staticView,
}: {
  slide: Slide; index: number; total: number; editing: boolean; onChange: (p: Partial<Slide>) => void;
  imageUrl?: string; imageLoading?: boolean; onRegenImage?: () => void; subject?: string; staticView?: boolean;
}) {
  if (!slide) return null;
  const sourceIndex = (slide as Slide & { sourceIndex?: number }).sourceIndex ?? index;
  imageUrl = renderLessonIllustrationDataUrl({ ...slide, subject, slideIndex: sourceIndex });
  const kind = slide.kind === "chapter" && slide.sections?.length ? "content" : slide.kind || "content";
  const lang = isLanguageSubject(subject);
  const v = slide.verification;
  const vTone = !v ? "" :
    v.coverage >= 80 ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30" :
    v.coverage >= 55 ? "bg-amber-500/10 text-amber-700 border-amber-500/30" :
    "bg-rose-500/10 text-rose-700 border-rose-500/30";

  // Break / MCQ / chapter slides use single-column layout.
  if (kind === "break" || kind === "mcq" || kind === "chapter") {
    return (
      <Card className="lesson-slide-canvas h-[calc(100dvh-7rem)] min-h-[560px] w-full overflow-hidden border-border/60 shadow-soft print:h-auto print:w-full">
        <CardContent className="h-full p-0 print:h-auto">
          <div className="relative grid h-full w-full grid-rows-[auto_1fr_auto] overflow-hidden bg-card print:h-auto">
            <div className="px-4 sm:px-6 pt-3 pb-2 border-b border-border/60 bg-secondary/40 flex items-center justify-between text-[11px] text-muted-foreground">
              <span className="font-mono">Slide {index + 1} / {total}</span>
              <Badge variant="outline" className={`rounded-full text-[10px] ${kind === "mcq" ? "bg-primary/10 text-primary border-primary/30" : kind === "break" ? "bg-amber-500/10 text-amber-700 border-amber-500/30" : "bg-sky-500/10 text-sky-700 border-sky-500/30"}`}>
                {kind === "mcq" ? "MCQ" : kind === "break" ? (slide.visual === "cover" ? "Chapter overview" : "Break") : "Chapter page"}
              </Badge>
            </div>
            <div className="min-h-0 overflow-hidden">
              <h3 className="px-6 pt-3 font-display text-lg sm:text-xl font-bold tracking-tight leading-tight line-clamp-2">{slide.title}</h3>
              {kind === "mcq" && <McqSlideBody slide={slide} staticView={staticView} />}
              {kind === "chapter" && <ChapterSlideBody slide={slide} />}
              {kind === "break" && <BreakSlideBody slide={slide} />}
            </div>
            <div className="px-4 sm:px-6 py-2 border-t border-border/60 bg-secondary/40 flex items-center justify-between text-[10px] text-muted-foreground">
              <span className="truncate max-w-[70%] italic">{slide.caption || slide.title}</span>
              <span className="font-mono shrink-0">EduPlan AI · A4</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="lesson-slide-canvas h-[calc(100dvh-7rem)] min-h-[560px] w-full overflow-hidden border-border/60 shadow-soft print:h-auto print:w-full">
      <CardContent className="h-full p-0 print:h-auto">
        <div className="relative grid h-full w-full grid-rows-[auto_1fr_auto] overflow-hidden bg-card print:h-auto">
          <div className="px-4 sm:px-6 pt-3 pb-2 border-b border-border/60 bg-secondary/40 flex items-center justify-between text-[11px] text-muted-foreground">
            <span className="font-mono">Slide {index + 1} / {total}</span>
            <div className="flex items-center gap-2">
              {v && (
                <Badge variant="outline" className={`rounded-full text-[10px] ${vTone}`}>
                  Notes {v.coverage}% · Diagram {v.diagram_match}% · Labels {v.diagram_label_fit}
                </Badge>
              )}
              {v?.figures_check && (v.figures_check.expected.length > 0 || v.figures_check.placed.length > 0) && (
                <Badge
                  variant="outline"
                  className={`rounded-full text-[10px] ${v.figures_check.pass ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30" : "bg-rose-500/10 text-rose-700 border-rose-500/30"}`}
                  title={
                    v.figures_check.pass
                      ? `Figures OK: ${v.figures_check.correct.join(", ") || "none"}`
                      : `Swapped: ${v.figures_check.swapped.join(", ") || "—"} · Missing: ${v.figures_check.missing.join(", ") || "—"}`
                  }
                >
                  Figures {v.figures_check.pass ? "✓" : "⚠"} {v.figures_check.correct.length}/{v.figures_check.expected.length}
                </Badge>
              )}
              {(v as any)?.notes_check && (
                <Badge
                  variant="outline"
                  className={`rounded-full text-[10px] ${(v as any).notes_check.pass ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30" : "bg-rose-500/10 text-rose-700 border-rose-500/30"}`}
                  title={
                    (v as any).notes_check.issues.length
                      ? (v as any).notes_check.issues.join(" ")
                      : "Notation renders correctly and vocabulary matches the retrieved source. These checks do not certify factual accuracy."
                  }
                >
                  Notation {(v as any).notes_check.pass ? "✓" : "⚠"} · Source match {(v as any).notes_check.grounding_confidence}%{(v as any).notes_check.latex_fixed ? ` · ${(v as any).notes_check.latex_fixed} auto-fixed` : ""}
                </Badge>
              )}
              <Badge variant="outline" className="rounded-full text-[10px]">
                {slide.notes_quality && !slide.notes_quality.ready ? "Source review needed" : "Textbook-based"}
              </Badge>

            </div>
          </div>

          <div className="lesson-slide-body grid grid-cols-1 md:grid-cols-[3fr_2fr] min-h-0 overflow-hidden" style={lang ? { gridTemplateColumns: "1fr" } : undefined}>
            <div className="px-5 sm:px-8 py-5 flex flex-col gap-3 min-h-0 overflow-hidden">
              {editing ? (
                <Input
                  value={slide.title}
                  onChange={(e) => onChange({ title: e.target.value })}
                  className="font-display text-[clamp(22px,2.2vw,32px)] font-bold border-0 px-0 shadow-none focus-visible:ring-0 h-auto"
                />
              ) : (
                <h3 className="font-display text-[clamp(22px,2.2vw,32px)] font-bold tracking-tight leading-tight shrink-0">{slide.title}</h3>
              )}
              {!(slide as any).sections?.length || editing ? (
                <ul className="space-y-1">
                  {(slide.bullets || []).map((b, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="mt-1.5 h-1 w-1 rounded-full bg-primary shrink-0" />
                      {editing ? (
                        <Textarea
                          value={b}
                          onChange={(e) => {
                            const next = [...slide.bullets];
                            next[i] = e.target.value;
                            onChange({ bullets: next });
                          }}
                          className="min-h-[32px] resize-none text-xs"
                        />
                      ) : (
                        <p className="text-[12px] leading-snug"><MathText text={b} /></p>
                      )}
                    </li>
                  ))}
                </ul>
              ) : null}
              <PagedNoteSections
                sections={slide.sections?.filter((section) => section.kind !== "diagram")}
                subject={subject}
                header={<PenNotesBlock index={sourceIndex} slide={slide} subject={subject} editable={!staticView} />}
              />


              {slide.notes?.length && !(slide as any).sections?.length ? (
                <div className="rounded-md bg-secondary/50 border border-border/50 p-2 overflow-hidden">
                  <div className="text-[9px] font-semibold uppercase tracking-wider text-primary mb-1">NCERT notes</div>
                  <ol className="space-y-0.5 list-decimal list-inside text-[11px] leading-snug text-foreground/85">
                    {slide.notes.map((n, i) => <li key={i}><MathText text={n} /></li>)}
                  </ol>
                </div>
              ) : null}
              {slide.key_terms?.length && !(slide as any).sections?.length ? (
                <div className="rounded-md bg-accent/20 border border-border/50 p-2 overflow-hidden">
                  <div className="text-[9px] font-semibold uppercase tracking-wider text-primary mb-1">Key terms</div>
                  <dl className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] leading-snug">
                    {slide.key_terms.map((t, i) => (
                      <div key={i}><dt className="font-semibold inline">{t.term}: </dt><dd className="inline text-muted-foreground">{t.meaning}</dd></div>
                    ))}
                  </dl>
                </div>
              ) : null}
              {editing && (
                <Input
                  value={slide.caption ?? ""}
                  placeholder="Caption (optional)"
                  onChange={(e) => onChange({ caption: e.target.value })}
                  className="text-[11px] h-8"
                />
              )}
              {slide.figures?.length && !(slide as any).sections?.length ? (
                <p className="text-[10px] text-muted-foreground">📖 Refer NCERT {slide.figures.join(", ")}</p>
              ) : null}
              {slide.ncert_quote && !(slide as any).sections?.length ? (
                <p className="text-[10px] italic text-muted-foreground border-l-2 border-primary/40 pl-2 line-clamp-2">“{slide.ncert_quote}”</p>
              ) : null}

            </div>
            <div className="relative bg-gradient-to-br from-primary/10 via-secondary to-accent/30 flex flex-col p-3 border-l border-border/60 overflow-hidden gap-2 min-h-0" style={lang ? { display: "none" } : undefined}>
              <div className="absolute top-2 left-2 z-10 text-[9px] font-mono text-muted-foreground bg-card/80 rounded px-1.5 py-0.5 border border-border/40">2D infographic · auto</div>
              <div className="lesson-figure-panel relative w-full flex-[3] rounded-md overflow-hidden bg-card shadow-soft border border-border/50 min-h-0 grid place-items-center">
                {isMathematics(subject) ? <MathematicsTopicVisual input={{ ...slide, keyTerms: slide.key_terms }} /> : imageUrl ? (
                  <img src={imageUrl} alt={`${slide.title} — NCERT 2D infographic`} className="w-full h-full object-contain" />
                ) : imageLoading ? (
                  <div className="flex flex-col items-center gap-2 text-[10px] text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    Drawing 2D infographic from NCERT notes…
                  </div>
                ) : (
                  <button onClick={onRegenImage} className="flex flex-col items-center gap-1 text-[10px] text-primary underline hover:no-underline">
                    <span>Retry 2D infographic</span>
                    <span className="text-muted-foreground no-underline">(free auto-render · cached)</span>
                  </button>
                )}
              </div>
              {/* Hide the 3D / simulation panel entirely for language subjects. */}
              {!lang && !staticView && (
                <div className="lesson-simulation-panel relative w-full flex-[2] rounded-md overflow-hidden bg-card shadow-soft border border-border/50 min-h-0">
                  <SimPanel slide={slide} index={sourceIndex} subject={subject} editable />
                </div>
              )}
            </div>
          </div>

          <div className="px-4 sm:px-6 py-2 border-t border-border/60 bg-secondary/40 flex items-center justify-between text-[10px] text-muted-foreground">
            <span className="truncate max-w-[70%] italic">{slide.caption || `NCERT-grounded summary — ${slide.title}`}</span>
            <span className="font-mono shrink-0">EduPlan AI · A4</span>
          </div>
        </div>

        {v && v.missing.length > 0 && (
          <div className="px-4 py-2 border-t border-border/60 text-[11px] text-muted-foreground print:hidden">
            <span className="font-semibold text-rose-700">Flagged as not directly matched in NCERT text:</span>{" "}
            {v.missing.map((m, i) => <span key={i} className="italic">“{m}”{i < v.missing.length - 1 ? "; " : ""}</span>)}
          </div>
        )}
      </CardContent>
    </Card>
  );
}


export {SlideCanvas};